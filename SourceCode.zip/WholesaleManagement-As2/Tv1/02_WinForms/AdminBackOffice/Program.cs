using System;
using System.Windows.Forms;
using AdminBackOffice.UI;

namespace AdminBackOffice
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm());
        }
    }
}
